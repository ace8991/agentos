"""
Central dispatcher. Checks app.config.is_tool_available() before executing
any desktop action — returns a clear error if called from cloud mode.
"""
import asyncio, logging, time, subprocess
import pyautogui
from app.models.schemas import AgentAction, ActionType
from app.config import is_tool_available, IS_CLOUD
from app.services import web, browser

logger = logging.getLogger(__name__)
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.05


async def execute(action: AgentAction, run_id: str) -> dict:
    t = action.type

    # Guard: block desktop actions in cloud mode
    if not is_tool_available(t.value):
        return {
            "success": False,
            "description": f"Tool '{t}' is not available in cloud mode. Use web_search, web_extract or browser_* instead.",
            "mode_error": True,
        }

    try:
        # ── Tavily ─────────────────────────────────────────────────
        if t == ActionType.WEB_SEARCH:
            return await asyncio.to_thread(web.web_search, action.query, action.max_results or 5)
        if t == ActionType.WEB_EXTRACT:
            return await asyncio.to_thread(web.web_extract, action.url)
        if t == ActionType.WEB_QNA:
            return await asyncio.to_thread(web.web_qna, action.query)
        if t == ActionType.WEB_CRAWL:
            return await asyncio.to_thread(web.web_crawl, action.url, action.instructions)

        # ── Playwright ─────────────────────────────────────────────
        if t == ActionType.BROWSER_OPEN:
            return await browser.browser_open(run_id, action.url, action.timeout or 15000)
        if t == ActionType.BROWSER_CLICK:
            return await browser.browser_click(run_id, action.selector, action.timeout or 8000)
        if t == ActionType.BROWSER_TYPE:
            return await browser.browser_type(run_id, action.selector, action.text, action.timeout or 8000)
        if t == ActionType.BROWSER_SELECT:
            return await browser.browser_select(run_id, action.selector, action.value, action.timeout or 8000)
        if t == ActionType.BROWSER_SCROLL:
            return await browser.browser_scroll(run_id, action.amount or 3)
        if t == ActionType.BROWSER_WAIT:
            return await browser.browser_wait(run_id, action.selector, action.timeout or 10000)
        if t == ActionType.BROWSER_SNAPSHOT:
            return await browser.browser_snapshot(run_id)
        if t == ActionType.BROWSER_EVAL:
            return await browser.browser_eval(run_id, action.script)
        if t == ActionType.BROWSER_BACK:
            return await browser.browser_back(run_id)
        if t == ActionType.BROWSER_CLOSE:
            await browser.close_session(run_id)
            return {"success": True, "description": "Browser closed"}

        # ── Claude Computer Use (local only) ───────────────────────
        if t == ActionType.COMPUTER_USE:
            from app.services.computer_use import run_computer_use
            return await asyncio.to_thread(
                run_computer_use,
                action.subtask or action.reason or "complete visible task",
                None,
                action.cu_max_iterations or 5,
            )

        # ── PyAutoGUI (local only) ─────────────────────────────────
        if t == ActionType.CLICK:
            return await asyncio.to_thread(_click, action.x, action.y)
        if t == ActionType.TYPE:
            return await asyncio.to_thread(_type, action.text)
        if t == ActionType.KEY:
            return await asyncio.to_thread(_key, action.key)
        if t == ActionType.SCROLL:
            return await asyncio.to_thread(_scroll, action.x, action.y, action.amount)
        if t == ActionType.WAIT:
            return await asyncio.to_thread(_wait, action.amount or 1)
        if t == ActionType.SHELL:
            return await asyncio.to_thread(_shell, action.command)

        if t == ActionType.DONE:
            return {"success": True, "description": "Task completed"}

        return {"success": False, "description": f"Unknown action: {t}"}

    except pyautogui.FailSafeException:
        return {"success": False, "description": "Fail-safe triggered — move mouse away from corner"}
    except Exception as e:
        logger.error(f"execute({t}): {e}")
        return {"success": False, "description": str(e)}


def _click(x, y):
    if x is None or y is None:
        return {"success": False, "description": "click requires x and y"}
    sw, sh = pyautogui.size()
    if not (0 <= x <= sw and 0 <= y <= sh):
        return {"success": False, "description": f"({x},{y}) out of screen {sw}x{sh}"}
    pyautogui.moveTo(x, y, duration=0.15)
    pyautogui.click()
    return {"success": True, "description": f"Clicked ({x}, {y})"}

def _type(text):
    if not text:
        return {"success": False, "description": "no text"}
    pyautogui.write(str(text), interval=0.03)
    return {"success": True, "description": f"Typed: {str(text)[:60]}"}

def _key(combo):
    if not combo:
        return {"success": False, "description": "no key"}
    keys = [k.strip() for k in str(combo).split("+")]
    pyautogui.hotkey(*keys) if len(keys) > 1 else pyautogui.press(keys[0])
    return {"success": True, "description": f"Key: {combo}"}

def _scroll(x, y, amount):
    amount = amount or 3
    if x and y: pyautogui.moveTo(x, y, duration=0.1)
    pyautogui.scroll(amount)
    return {"success": True, "description": f"Scrolled {amount}"}

def _wait(seconds):
    time.sleep(min(int(seconds), 15))
    return {"success": True, "description": f"Waited {seconds}s"}

def _shell(cmd):
    if not cmd:
        return {"success": False, "description": "no command"}
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        return {"success": r.returncode == 0,
                "stdout": r.stdout[:2000], "stderr": r.stderr[:400],
                "description": f"Exit {r.returncode}: {r.stdout[:100]}"}
    except subprocess.TimeoutExpired:
        return {"success": False, "description": "timed out"}
