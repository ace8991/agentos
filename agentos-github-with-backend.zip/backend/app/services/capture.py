import mss
import base64
from io import BytesIO
from PIL import Image


def capture_screenshot(monitor_index: int = 1, quality: int = 75) -> str:
    """Capture screen and return base64-encoded JPEG."""
    with mss.mss() as sct:
        monitor = sct.monitors[monitor_index] if len(sct.monitors) > monitor_index else sct.monitors[0]
        screenshot = sct.grab(monitor)
        img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")

    # Resize to max 1280px wide to reduce token usage
    max_width = 1280
    if img.width > max_width:
        ratio = max_width / img.width
        img = img.resize((max_width, int(img.height * ratio)), Image.LANCZOS)

    buffer = BytesIO()
    img.save(buffer, format="JPEG", quality=quality)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def capture_region(x: int, y: int, width: int, height: int) -> str:
    """Capture a specific screen region."""
    with mss.mss() as sct:
        region = {"top": y, "left": x, "width": width, "height": height}
        screenshot = sct.grab(region)
        img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")

    buffer = BytesIO()
    img.save(buffer, format="JPEG", quality=80)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")
