import os, platform
from fastapi import APIRouter
from app.config import MODE, IS_LOCAL, CLOUD_TOOLS, DESKTOP_TOOLS

router = APIRouter()

@router.get("/health")
async def health():
    info = {
        "status": "ok",
        "version": "1.0.0",
        "mode": MODE,
        "available_tools": {
            "tavily":       bool(os.getenv("TAVILY_API_KEY")),
            "playwright":   True,
            "pyautogui":    IS_LOCAL,
            "computer_use": IS_LOCAL,
        },
        "system": {
            "os": platform.system(),
            "anthropic_key": bool(os.getenv("ANTHROPIC_API_KEY")),
            "tavily_key":    bool(os.getenv("TAVILY_API_KEY")),
            "openai_key":    bool(os.getenv("OPENAI_API_KEY")),
        },
    }
    if IS_LOCAL:
        import pyautogui, mss
        sw, sh = pyautogui.size()
        with mss.mss() as s:
            info["system"]["screen"] = f"{sw}x{sh}"
            info["system"]["monitors"] = len(s.monitors) - 1
    return info
