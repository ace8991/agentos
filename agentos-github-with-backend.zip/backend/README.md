# AgentOS Pro — Hybrid AI Agent Platform

Two deployment modes, one codebase:

| Mode | Déploiement | Outils disponibles |
|---|---|---|
| **Cloud** | Docker / Railway / Render | Tavily + Playwright headless |
| **Local** | Binaire .exe/.app | Tavily + Playwright + PyAutoGUI + Computer Use |

## Setup rapide

### Mode Cloud (Docker)
```bash
cp .env.example .env   # remplir ANTHROPIC_API_KEY + TAVILY_API_KEY
docker-compose up -d
# Backend sur http://localhost:8000
```

### Déploiement cloud (Railway / Render)
```bash
# Railway
railway login && railway init && railway up

# Render: connecter le repo GitHub, choisir Dockerfile
# Variables d'env: ANTHROPIC_API_KEY, TAVILY_API_KEY
```

### Mode Local (binaire)
```bash
# macOS / Linux
chmod +x build.sh && ./build.sh
ANTHROPIC_API_KEY=sk-ant-... TAVILY_API_KEY=tvly-... ./dist/AgentOS

# Windows
build.bat
# puis: dist\AgentOS.exe
```

### Mode Local (développement)
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
playwright install chromium
cp .env.example .env   # remplir les clés
python run.py
```

## Architecture

```
config.py      ← MODE detection (cloud|local), is_tool_available()
brain.py       ← LLM avec system prompt adapté au mode
executor.py    ← dispatcher avec guard mode
routes/
  health.py    ← GET /health → mode + available_tools
  agent.py     ← POST /start /stop  GET /stream/{id}
services/
  web.py       ← Tavily (cloud + local)
  browser.py   ← Playwright (cloud headless / local visible)
  executor.py  ← PyAutoGUI + Computer Use (local only)
  capture.py   ← mss screenshot (local only)
  runner.py    ← boucle perceive→plan→act
```

## Détection automatique du mode

| Condition | Mode |
|---|---|
| `AGENT_MODE=cloud` dans env | Cloud |
| `AGENT_MODE=local` dans env | Local |
| Linux sans `$DISPLAY` | Cloud (auto) |
| Tout autre cas | Local (auto) |

## /health response

```json
{
  "status": "ok",
  "mode": "local",
  "available_tools": {
    "tavily": true,
    "playwright": true,
    "pyautogui": true,
    "computer_use": true
  }
}
```

Le frontend lit `mode` et `available_tools` pour adapter l'UI.
